const MongoClient = require('mongodb').MongoClient;

const uri = 'mongodb://127.0.0.1:27017';
const databaseName = 'mongodbtestaltered'; // Replace with your database name
const collectionName = 'documents'; // Replace with your collection name
const numberOfDocuments = 1000; // Number of documents to update

async function updateDocument() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Access the database and collection
    const db = client.db(databaseName);
    const collection = db.collection(collectionName);

    // Find the first 1000 documents and update the "column2" field to "name"
    const documentsToUpdate = await collection.find().limit(numberOfDocuments).toArray();
    const updatePromises = documentsToUpdate.map(document => {
      return collection.updateOne({ _id: document._id }, { $set: { column2: 'name' } });
    });
    await Promise.all(updatePromises);

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds

    console.log(`Updated ${numberOfDocuments} document(s) in the collection: ${collectionName}`);
    console.log(`Time taken to update the document(s): ${elapsedTime}ms`);

    // Close the MongoDB connection
    await client.close();
    console.log('Disconnected from MongoDB');
  } catch (error) {
    console.error('Error:', error);
  }
}
updateDocument();

