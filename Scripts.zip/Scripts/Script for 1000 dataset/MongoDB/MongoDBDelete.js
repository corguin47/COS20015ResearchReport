const MongoClient = require('mongodb').MongoClient;

const uri = 'mongodb://127.0.0.1:27017';
const databaseName = 'mongodbtestaltered'; // Replace with your database name
const collectionName = 'documents'; // Replace with your collection name
const numberOfDocumentsToDelete = 1000; // Number of documents to delete

async function deleteDocuments() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Access the database and collection
    const db = client.db(databaseName);
    const collection = db.collection(collectionName);

    // Find the documents to delete
    const documentsToDelete = await collection.find().limit(numberOfDocumentsToDelete).toArray();

    // Get the IDs of the documents to delete
    const documentIds = documentsToDelete.map(doc => doc._id);

    // Delete the documents by ID
    const result = await collection.deleteMany({ _id: { $in: documentIds } });

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds

    console.log(`Deleted ${result.deletedCount} document(s) from the collection: ${collectionName}`);
    console.log(`Time taken to delete ${result.deletedCount} document(s): ${elapsedTime}ms`);

    // Close the MongoDB connection
    await client.close();
    console.log('Disconnected from MongoDB');
  } catch (error) {
    console.error('Error:', error);
  }
}

deleteDocuments();
