const MongoClient = require('mongodb').MongoClient;

const uri = 'mongodb://127.0.0.1:27017';
const databaseName = 'mongodbtestaltered'; // Replace with your database name

async function dropDatabase() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Access the database
    const db = client.db(databaseName);

    // Drop the database
    await db.dropDatabase();
    console.log(`Dropped the database: ${databaseName}`);

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to drop the database: ${elapsedTime}ms`);

    // Close the MongoDB connection
    await client.close();
    console.log('Disconnected from MongoDB');
  } catch (error) {
    console.error('Error:', error);
  }
}

dropDatabase();
