const MongoClient = require('mongodb').MongoClient;

// this url is depends on your own device settings
const uri = 'mongodb://127.0.0.1:27017';
const databaseName = 'mongodbtest'; // Replace with your desired database name
const collectionName = 'documents'; // Replace with your desired collection name

async function createTable() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Access the database
    const db = client.db(databaseName);

    // Create the collection
    await db.createCollection(collectionName);
    console.log(`Created the collection: ${collectionName}`);

    // Measure the end time after creating the collection
    const collectionEndTime = new Date();
    const collectionElapsedTime = collectionEndTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to create the collection / database : ${collectionElapsedTime}ms`);

    // Define a sample document (to ensure it has 5 columns)
    const document = {
      column1: 'value1',
      column2: 'value2',
      column3: 'value3',
      column4: 'value4',
      column5: 'value5'
    };

    // Insert the document into the collection
    await db.collection(collectionName).insertOne(document);

    // Close the MongoDB connection
    await client.close();

    // Measure the end time after closing the connection
    const databaseEndTime = new Date();
    const databaseElapsedTime = databaseEndTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to create and discoonect from the database: ${databaseElapsedTime}ms`);
  } catch (error) {
    console.error('Error:', error);
  }
}

createTable();
