const MongoClient = require('mongodb').MongoClient;

const uri = 'mongodb://127.0.0.1:27017';
// the initial database name
const originalDatabaseName = 'mongodbtest';
// the new database name
const updatedDatabaseName = 'mongodbtestaltered';

async function updateDatabaseName() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Get the original database instance
    const originalDb = client.db(originalDatabaseName);

    // Create the updated database instance
    await client.db().admin().command({ renameCollection: `${originalDatabaseName}.documents`, to: `${updatedDatabaseName}.documents` });
    const updatedDb = client.db(updatedDatabaseName);


    // this is only used when the database contains documents. if not, then it is not needed
    // Get all documents from the original database
    // const documents = await originalDb.collection('documents').find({}).toArray();

    // Copy documents to the updated database
    // await updatedDb.collection('documents').insertMany(documents);

    // Drop the original database
    await originalDb.dropDatabase();

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to update the database name: ${elapsedTime}ms`);

    console.log(`Updated the name of the database to: ${updatedDatabaseName}`);

    // Close the MongoDB connection
    await client.close();
    console.log('Disconnected from MongoDB');
  } catch (error) {
    console.error('Error:', error);
  }
}

updateDatabaseName();
