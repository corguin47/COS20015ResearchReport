const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const databaseName = 'couchdbtestaltered';

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function run() {
  try {
    // Connect to the CouchDB database
    const db = nano.db.use(databaseName);
    console.log('Connected to CouchDB');

    // Measure the start time for delete operation
    const startTime = new Date();

    // Retrieve the first 1000 documents
    try {
      const result = await db.find({
        selector: {},
        limit: 1000
      });

      const documentsToDelete = result.docs;

      // Generate an array of documents with _id and _rev for deletion
      const deletionDocuments = documentsToDelete.map(doc => {
        return {
          _id: doc._id,
          _rev: doc._rev,
          _deleted: true
        };
      });

      // Perform the bulk delete operation
      await db.bulk({ docs: deletionDocuments });

      console.log(`Deleted ${deletionDocuments.length} documents`);
    } catch (error) {
      console.error('Error deleting data:', error);
    }

    // Measure the end time for delete operation
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference for delete operation in milliseconds

    console.log(`Time taken: ${elapsedTime}ms`);

  } catch (error) {
    console.error('Error:', error);
  }
}

run();
