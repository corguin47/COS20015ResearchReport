const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const databaseName = 'couchdbtest'; // Replace with your desired database name

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function createTable() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Create the database
    await nano.db.create(databaseName);
    console.log(`Created the database: ${databaseName}`);

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to create the table: ${elapsedTime}ms`);

    // Connect to the newly created database
    const db = nano.db.use(databaseName);

    // Define a sample document
    const document = {
      column1: 'value1',
      column2: 'value2',
      column3: 'value3',
      column4: 'value4',
      column5: 'value5'
    };

  } catch (error) {
    console.error('Error:', error);
  }
}

createTable();