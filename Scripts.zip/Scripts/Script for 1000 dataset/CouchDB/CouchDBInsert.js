const fs = require('fs');
const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const databaseName = 'couchdbtestaltered';
const collectionName = 'jgcollection';

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function run() {
  try {
    // Read the TSV file
    const tsvData = fs.readFileSync('100000Data.tsv', 'utf-8');

    // Split the TSV data into rows and process each row
    const rows = tsvData.split('\n');
    const documents = [];
    for (let i = 0; i < 1000; i++) { // Modify the loop to stop at 1000 iterations
      const values = rows[i].split('\t');

      // the TSV has 5 columns
      const document = {
        column1: values[0],
        column2: values[1],
        column3: values[2],
        column4: values[3],
        column5: values[4]
      };

      documents.push(document);
    }

    // Connect to the CouchDB database
    const db = nano.db.use(databaseName);
    console.log('Connected to CouchDB');

    // Clear the collection before inserting new documents
    try {
      await db.destroy();
      await nano.db.create(databaseName);
      console.log('Deleted and recreated the database');
    } catch (error) {
      console.error('Error deleting or creating the database:', error);
    }

    // Measure the start time
    const startTime = new Date();

    // Insert the documents into the collection
    try {
      const response = await db.bulk({ docs: documents });
      console.log(`Inserted ${response.length} documents`);
    } catch (error) {
      console.error('Error inserting data:', error);
    }

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds

    console.log(`Time taken: ${elapsedTime}ms`);
    

  } catch (error) {
    console.error('Error:', error);
  }
}

run();
