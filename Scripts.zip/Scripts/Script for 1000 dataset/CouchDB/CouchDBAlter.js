const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const originalDatabaseName = 'couchdbtest';
const updatedDatabaseName = 'couchdbtestaltered';

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function updateDatabaseName() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Create a new database with the updated name
    await nano.db.create(updatedDatabaseName);

    // Get the original database instance
    const originalDb = nano.db.use(originalDatabaseName);

    // Get the updated database instance
    const updatedDb = nano.db.use(updatedDatabaseName);

    // Get all documents from the original database
    const { rows } = await originalDb.list({ include_docs: true });

    // Copy documents to the updated database
    const copiedDocuments = rows.map(row => {
      const document = row.doc;
      delete document._rev; // Remove the revision property
      return document;
    });

    await updatedDb.bulk({ docs: copiedDocuments });

    // Delete the original database
    await nano.db.destroy(originalDatabaseName);

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to update the database name: ${elapsedTime}ms`);

    console.log(`Updated the name of the database to: ${updatedDatabaseName}`);
  } catch (error) {
    console.error('Error:', error);
  }
}

updateDatabaseName();
