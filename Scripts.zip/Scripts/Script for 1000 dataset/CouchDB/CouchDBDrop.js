const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const databaseName = 'couchdbtestaltered'; // Replace with the name of the database you want to drop

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function dropDatabase() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Drop the database
    await nano.db.destroy(databaseName);
    console.log(`Dropped the database: ${databaseName}`);

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to drop the database: ${elapsedTime}ms`);
  } catch (error) {
    console.error('Error:', error);
  }
}

dropDatabase();