const fs = require('fs');
const readline = require('readline');
const MongoClient = require('mongodb').MongoClient;

const uri = 'mongodb://127.0.0.1:27017';
const databaseName = 'mongodbtestaltered'; // Replace with your desired database name
const collectionName = 'documents'; // Replace with your desired collection name

async function insertDataFromFile() {
  try {
    // Measure the start time
    const startTime = new Date();

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Access the database
    const db = client.db(databaseName);

    // Read the file line by line
    const fileStream = fs.createReadStream('100000Data.tsv');
    const rl = readline.createInterface({ input: fileStream });

    // Define an array to store the documents
    let documents = [];

    // Process each line and create a document
    for await (const line of rl) {
      // Split the line by tab separator
      const data = line.split('\t');

      // Create a document object
      const document = {
        column1: data[0],
        column2: data[1],
        column3: data[2],
        column4: data[3],
        column5: data[4]
      };

      // Add the document to the array
      documents.push(document);

      // Break the loop when 10000 documents are reached
      if (documents.length === 10000) {
        break;
      }
    }

    // Insert the documents into the collection
    await db.collection(collectionName).insertMany(documents);
    console.log(`Inserted ${documents.length} documents into the collection`);

    // Measure the end time
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference in milliseconds
    console.log(`Time taken to insert ${documents.length} documents: ${elapsedTime}ms`);

    // Close the MongoDB connection
    await client.close();
    console.log('Disconnected from MongoDB');
  } catch (error) {
    console.error('Error:', error);
  }
}

insertDataFromFile();
