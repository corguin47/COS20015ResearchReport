const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const databaseName = 'couchdbtestaltered';

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function run() {
  try {
    // Connect to the CouchDB database
    const db = nano.db.use(databaseName);
    console.log('Connected to CouchDB');

    // Measure the start time for select operation
    const startTime = new Date();

    // Perform the SELECT query to retrieve first 10000 rows
    const selectedDocuments = [];
    try {
      const result = await db.find({
        selector: {},
        limit: 10000
      });

      selectedDocuments.push(...result.docs);
      console.log(`Selected ${selectedDocuments.length} documents`);
    } catch (error) {
      console.error('Error selecting data:', error);
    }

    // Measure the end time for select operation
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference for select operation in milliseconds

    console.log(`Time taken: ${elapsedTime}ms`);

  } catch (error) {
    console.error('Error:', error);
  }
}

run();
