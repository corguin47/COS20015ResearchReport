const Nano = require('nano');

const uri = 'http://adminJG:data@127.0.0.1:5984/';
const databaseName = 'couchdbtestaltered';

// Create a Nano instance and connect to CouchDB
const nano = Nano(uri);

async function run() {
  try {
    // Connect to the CouchDB database
    const db = nano.db.use(databaseName);
    console.log('Connected to CouchDB');

    // Measure the start time for update operation
    const startTime = new Date();

    // Retrieve the first 10000 documents
    try {
      const result = await db.find({
        selector: {},
        limit: 10000
      });

      const documentsToUpdate = result.docs;

      // Update the second column of each document to 'name'
      const updatedDocuments = documentsToUpdate.map(doc => {
        doc.column2 = 'name';
        return doc;
      });

      // Perform the bulk update operation
      await db.bulk({ docs: updatedDocuments });

      console.log(`Updated ${updatedDocuments.length} documents`);
    } catch (error) {
      console.error('Error updating data:', error);
    }

    // Measure the end time for update operation
    const endTime = new Date();
    const elapsedTime = endTime - startTime; // Time difference for update operation in milliseconds

    console.log(`Time taken: ${elapsedTime}ms`);

  } catch (error) {
    console.error('Error:', error);
  }
}

run();
